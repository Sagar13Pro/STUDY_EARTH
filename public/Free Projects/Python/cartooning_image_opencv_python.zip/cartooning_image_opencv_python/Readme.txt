Dependencies:
-cv2
-numpy  
Those are required libraries that must on your local PC.

Note: cv2 module is changed to opencv on later python version.
Try running pip install opencv-python just for installing with pip.But it can import to your code as import cv2.
For More information visit: https://pypi.org/project/opencv-python/